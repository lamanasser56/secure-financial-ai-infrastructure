# Dedicated synthetic evaluation cluster: proposed contract

This unapplied root proposes a small Standard GKE cluster with Dataplane V2 and native FQDN enforcement. It imports no existing cluster, VPC, subnet, node identity or workload. It is part of the [single execution proposal](https://github.com/lamanasser56/secure-financial-ai-infrastructure/tree/v1-live-evidence/docs/security/google-sdp-synthetic-execution-proposal.md), which is **pending approval**. Presidio remains authoritative; no production or real-data use is authorized.

## Resources and lifecycle

Nine Terraform resources define a custom VPC, subnet, static NAT address, router, NAT, dedicated node GSA, minimum node-role binding and cluster and one separate node pool. Names are `google-sdp-evaluation`, except NAT address `google-sdp-evaluation-nat` and GSA `google-sdp-evaluation-node`. The cluster is in `us-east1-b`; the proposed registry, state bucket and SDP endpoint are also in `us-east1`. This does not establish Saudi residency. One `e2-standard-2` node has a 20 GiB balanced boot disk, no external node IP, no autoscaler and no upgrade surge. GKE creates one temporary default node using the same hardened identity/configuration, removes that pool, then creates the separately managed one-node pool. This lifecycle is explicit; it does not alter the existing cluster.

The VPC has no peering or connection to the existing VPC. Its subnet uses `10.240.0.0/24`, with Pod range `10.241.0.0/20`, Service range `10.242.0.0/24` and master range `172.16.0.0/28`. These are isolated reference allocations, not imported addresses. Private Google Access is enabled. NAT covers only this subnet, using one explicitly allocated address. NAT supplies routing, not authorization; an evaluation Pod's egress is controlled by the [native package](https://github.com/lamanasser56/secure-financial-ai-infrastructure/tree/v1-live-evidence/kubernetes/apps/google-sdp-evaluation/README.md). No custom broad ingress firewall, Service, ingress controller, mesh or TLS interception is introduced. GKE creates its normal managed VM, disk, instance-group, internal firewall and control-plane resources; inspect those after creation.

The dedicated node GSA has the officially documented minimum [Kubernetes Engine Default Node Service Account role](https://docs.cloud.google.com/kubernetes-engine/security/configure-node-service-accounts), `roles/container.defaultNodeServiceAccount`, at project scope. The separate [identity root](../google-sdp-evaluation/README.md) grants it `roles/artifactregistry.reader` on the evaluation repository only. It receives no SDP role, writer, key or GitHub trust. Cloud-platform scopes are bounded by those IAM grants. The runtime GSA remains separate.

`evaluation_cluster_enabled=false` is the proposed cleanup setting. A saved cleanup plan must remove exactly the eight cluster/network/node-role resources and disable the retained node GSA. Its inactive repository-reader binding and identity-root resources remain state-backed. The bucket and final evidence are retained. Re-enabling the cluster requires a later approved milestone; reuse means the tested source and disabled identity, not an indefinitely running cluster. Never destroy another root or disable shared APIs.

## Native feature and operator access

The qualified Google provider 8.5.0 binary's offline schema includes `enable_fqdn_network_policy`; it is explicitly set in Terraform. No beta provider, provider upgrade or imperative enablement workaround is needed. The cluster uses `ADVANCED_DATAPATH`, IPv4, standard kube-dns, no NodeLocal cache and no Cloud Service Mesh. Dataplane V2 already enforces NetworkPolicy; do not also configure Calico enforcement. The exact GKE 1.35 REGULAR-channel version is supplied from the private reviewed inventory, never guessed or committed as an environment value.

### Version scopes and provider contract

Keep `remove_default_node_pool=true` with `initial_node_count=1`. Provider
8.5.0 rejects cluster-level `node_version` in this configuration because that
field controls the default pool. The root therefore omits it, preserves
`min_master_version=var.gke_version` for initial control-plane creation and
pins the separate managed pool through its own `version=var.gke_version`.
Inspect the temporary default pool's behavior and actual versions during
creation; static validation does not prove the cloud API accepts every setting.
See the [locked provider implementation](https://github.com/hashicorp/terraform-provider-google/blob/v8.5.0/google/services/container/resource_container_cluster.go).

Record the reviewed infrastructure commit separately from image provenance.
An infrastructure-only repair reuses a previously verified exact registry
digest and signature whose workflow/source identity remains the image release
commit. Its signature does not sign the newer Terraform source. Reverify that
exact image provenance before applying the reviewed cloud-backed saved plan;
do not move the release WIF source pin or dispatch another release solely for
an infrastructure repair. No request-selected image or region is allowed.

Only the IAM-authenticated DNS control-plane endpoint admits external operator traffic. Both IP-based endpoints and Kubernetes token/certificate authentication over DNS are disabled. Private nodes, shielded nodes, secure boot, integrity monitoring and GKE metadata mode are explicit. Cloud Shell can use the [DNS endpoint](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/latest/network-isolation); no Pod Kubernetes RBAC is granted. System/workload logs and system metrics remain enabled; managed Prometheus and unnecessary workload add-ons are disabled. Sampled VPC flow logs and NAT error logs complement the separately scoped NetworkLogging policy.

## Validation and state

Terraform compatibility and the Google 8.5.0 lock match the existing identity root. Run format, `init -backend=false -input=false -lockfile=readonly`, validation and Trivy configuration checks on the worker. These are offline checks, not a cloud plan. The [execution contract validator](https://github.com/lamanasser56/secure-financial-ai-infrastructure/tree/v1-live-evidence/scripts/validate-google-sdp-execution.py) and [regression tests](https://github.com/lamanasser56/secure-financial-ai-infrastructure/tree/v1-live-evidence/tests/phase5/test_google_sdp_native_execution.py) reject broad IAM, imports, multiple nodes, disabled enforcement and authority expansion.

Real initialization uses the approved GCS bucket and this root's separate `portfolio/google-sdp-evaluation-cluster` prefix. Initialize the identity root under its existing prefix. Keep actual tfvars, state and saved plans outside Git. Required Compute, GKE, Logging and Monitoring APIs are operator prerequisites already found enabled; this root does not enable them. Only after bundle approval and backend bootstrap may the authenticated operator save, inspect and apply plans. First use `evaluation_cluster_enabled=false` to create only the disabled node GSA, then apply the identity root against that existing account. Create compute/network with a later saved plan and the flag true only after the signed image is verified; release/reviewer waiting must not consume the six-hour cluster window. Stop on name collisions, unrelated changes, replacements, wider permissions, unsupported settings or a spending-limit risk. No cloud-backed saved plan exists yet.
