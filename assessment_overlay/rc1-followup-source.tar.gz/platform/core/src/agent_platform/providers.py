"""Provider profiles (providers/<name>.yaml) -> gateway configuration + egress allowlist.

`make provider P=<name>` calls `python -m agent_platform.providers render <name>`. Only an active,
owner-approved profile renders; applications only ever see the stable alias. Output is deterministic so
the committed generated files can be checked for drift in `make test`.
"""
import json
from pathlib import Path
import re
import sys

import yaml

REPO = Path(__file__).resolve().parents[4]
PROFILES = REPO / 'providers'
GATEWAY_CONFIG = REPO / 'platform/core/kubernetes/platform/generated/litellm.yaml'
EGRESS = REPO / 'platform/clouds/gke/kubernetes/generated/provider-egress.yaml'
ALIAS = 'secure-financial-chat'
MAX_TOKENS = 1024  # fixed by the qualified core request; thinking tokens count against it


class ProfileRejected(ValueError):
    pass


def load(name):
    if not re.fullmatch(r'[a-z][a-z0-9-]{1,30}', name or ''):
        raise ProfileRejected('profile name')
    path = PROFILES / (name + '.yaml')
    profile = yaml.safe_load(path.read_text())
    if not isinstance(profile, dict) or profile.get('profile') != name or profile.get('alias') != ALIAS:
        raise ProfileRejected('profile identity')
    if profile.get('status') != 'active' or not isinstance(profile.get('approved'), dict):
        raise ProfileRejected('inactive profile: owner approval of cost and data destination required')
    model, credential, egress = profile.get('model') or {}, profile.get('credential') or {}, profile.get('egress') or {}
    if not re.fullmatch(r'[a-z_]+/[a-z0-9.\-]+', str(model.get('litellm_model', ''))) or 'latest' in model['litellm_model']:
        raise ProfileRejected('model must be an exact pinned version')
    for key in ('input_cost_per_token', 'output_cost_per_token'):
        if type(model.get(key)) is not float or not 0 < model[key] < 0.001:
            raise ProfileRejected('explicit cost required for budget enforcement: ' + key)
    limits = model.get('limits') or {}
    if limits != {'timeout_seconds': 8, 'max_tokens': MAX_TOKENS, 'max_retries': 0}:
        raise ProfileRejected('limits')
    # none/disable: LiteLLM 1.104.0 sends includeThoughts=false. low: thought text is returned and the gateway hook
    # (programs/gateway_hooks.py) removes it before the reply leaves the gateway. Higher efforts are refused.
    if model.get('reasoning_effort', 'none') not in ('none', 'disable', 'low'):
        raise ProfileRejected('reasoning_effort outside the approved thinking levels')
    if credential.get('type') not in ('workload_identity', 'api_key'):
        raise ProfileRejected('credential type')
    hosts = egress.get('fqdn')
    if (not isinstance(hosts, list) or not hosts or egress.get('port') != 443
            or not all(re.fullmatch(r'[a-z0-9.\-]+\.[a-z]{2,}', h) for h in hosts)):
        raise ProfileRejected('egress allowlist')
    if (profile.get('budget') or {}).get('monthly_usd') != 10:
        raise ProfileRejected('budget')
    return profile


def gateway_config(profile):
    model = profile['model']
    params = {'model': model['litellm_model'], 'timeout': 8, 'max_retries': 0, 'max_tokens': MAX_TOKENS,
              'input_cost_per_token': model['input_cost_per_token'], 'output_cost_per_token': model['output_cost_per_token']}
    if model['litellm_model'].startswith('vertex_ai/'):
        params |= {'vertex_project': 'os.environ/PORTFOLIO_PROJECT_ID', 'vertex_location': model['vertex_location']}
    if 'reasoning_effort' in model:
        params['reasoning_effort'] = model['reasoning_effort']
    if profile['credential']['type'] == 'api_key':
        params['api_key'] = 'os.environ/' + profile['credential']['secret']['env']
    return {
        'model_list': [{'model_name': ALIAS, 'litellm_params': params}],
        'litellm_settings': {'num_retries': 0, 'telemetry': False, 'set_verbose': False,
                             'turn_off_message_logging': True, 'drop_params': False,
                             'callbacks': 'gateway_hooks.thought_signature_boundary'},  # /config/gateway_hooks.py
        'router_settings': {'num_retries': 0, 'fallbacks': [], 'context_window_fallbacks': [],
                            'content_policy_fallbacks': []},
        'general_settings': {'master_key': 'os.environ/LITELLM_MASTER_KEY', 'database_url': 'os.environ/DATABASE_URL',
                             # key spend (budget) is tracked without per-request spend log rows
                             'store_model_in_db': False, 'allow_requests_on_db_unavailable': False,
                             'disable_spend_logs': True, 'user_api_key_cache_ttl': 0},
    }


def egress_policy(profile):
    return {'apiVersion': 'networking.gke.io/v1alpha1', 'kind': 'FQDNNetworkPolicy',
            'metadata': {'name': 'gateway-provider', 'namespace': 'platform',
                         'annotations': {'policy.network.gke.io/enable-logging': 'true',
                                         'agent-platform/provider-profile': profile['profile']}},
            'spec': {'podSelector': {'matchLabels': {'app.kubernetes.io/name': 'gateway'}},
                     'egress': [{'matches': [{'name': h} for h in profile['egress']['fqdn']],
                                 'ports': [{'protocol': 'TCP', 'port': 443}]}]}}


HEADER = '# GENERATED by `make provider P={name}` from providers/{name}.yaml. Do not edit.\n'


class _IndentedDumper(yaml.SafeDumper):
    """Indent block sequences under their key (the repository's yamllint style)."""

    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)


def dump(value):
    return yaml.dump(value, Dumper=_IndentedDumper, sort_keys=True, default_flow_style=False)


def render(name):
    profile = load(name)
    return {GATEWAY_CONFIG: HEADER.format(name=name) + dump(gateway_config(profile)),
            EGRESS: HEADER.format(name=name) + dump(egress_policy(profile))}


def main(argv):
    if len(argv) != 2 or argv[0] not in ('render', 'check'):
        raise SystemExit('usage: python -m agent_platform.providers render|check <profile>')
    try:
        outputs = render(argv[1])
    except (ProfileRejected, OSError, yaml.YAMLError) as error:
        raise SystemExit('provider:rejected:' + str(error))
    if argv[0] == 'check':
        drift = [str(p.relative_to(REPO)) for p, text in outputs.items() if not p.exists() or p.read_text() != text]
        print(json.dumps({'profile': argv[1], 'drift': drift}))
        raise SystemExit(1 if drift else 0)
    for path, text in outputs.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    print(json.dumps({'profile': argv[1], 'rendered': sorted(str(p.relative_to(REPO)) for p in outputs)}))


if __name__ == '__main__':
    main(sys.argv[1:])
